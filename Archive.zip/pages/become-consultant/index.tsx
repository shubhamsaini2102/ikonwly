export default function BecomeConsultant() {
  return (
    <div>
          Become-consultant page content
    </div>
  );
}

