export default function About() {
  return (
    <div>
        About page content
    </div>
  );
}
  