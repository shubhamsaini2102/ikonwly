export default function companyterms() {
  return (
    <div>
              company-terms page content
    </div>
  );
}
    
    