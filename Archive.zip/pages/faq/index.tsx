export default function faq() {
  return (
    <div>
                faq page content
    </div>
  );
}
      
      