export default function careerlistingminimal() {
  return (
    <div>
            career-listing-minimal page content
    </div>
  );
}
  
  