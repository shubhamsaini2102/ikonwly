export default function helpCenter() {
  return (
    <div>
         help center page content
    </div>
  );
}
        
        